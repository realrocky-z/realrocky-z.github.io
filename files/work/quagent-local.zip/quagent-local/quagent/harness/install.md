# MCP 客户端接入

从解压根目录安装依赖并运行 START_HERE.md 中的自测命令。
在客户端自己的配置界面添加 stdio MCP 服务：命令 python，参数为解压后 quagent/server/mcp_server.py 的本机路径。
不同客户端配置格式可能不同，请依其官方文档配置。本包不附带个人电脑配置或凭据。
