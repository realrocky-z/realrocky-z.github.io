# 挂载到 DeepSeek Harness

## 前置

1. Python 在 `D:\Python\python.exe`，且已安装 `mcp`（本机为 1.28.1）。
2. 数据库已生成：`scenario/anticheat.db`。
3. MCP 服务器自测通过：`python server/smoke_mcp.py` 输出 `ALL PASS`。

## 步骤

1. 备份配置：

   ```bash
   cp ~/.dsh/profiles/desktop/cordis.patch.yml ~/.dsh/profiles/desktop/cordis.patch.yml.bak
   ```

2. 把 `harness/cordis.snippet.yml` 的内容追加到 `~/.dsh/profiles/desktop/cordis.patch.yml` 末尾。该文件是顶层 YAML 列表，直接追加一项即可。

3. 重启 DeepSeek Harness。

4. 在对话里问：「你现在有哪些取数工具？」或直接问一个业务问题。工具名应为 `mcp__qujian__get_scenario`、`mcp__qujian__run_sql` 等。

5. 若工具没有出现，按顺序检查：
   - Harness 的开发者工具控制台或应用日志里是否有 `mcp-qujian` 的连接错误；
   - 手动执行 `D:\Python\python.exe server\mcp_server.py`，确认不报缺少模块；
   - 配置里的路径是否含中文或空格但未用单引号包住；
   - `QUJIAN_DB` 是否指向真实存在的 `anticheat.db`。

## 回滚

```bash
cp ~/.dsh/profiles/desktop/cordis.patch.yml.bak ~/.dsh/profiles/desktop/cordis.patch.yml
```

重启 Harness 后，`mcp__qujian__*` 工具消失。备份文件不存在时，删除追加的 `- insert:` 整段即可。

## 说明

- 桌面端使用 `profiles/desktop`；如果用 `npx @deepseek-ai/dsh web`，改 `profiles/web/cordis.patch.yml`。
- MCP 服务器只提供只读工具；模型以 `mcp__qujian__<tool>` 的形式调用。
- 不需要 API Key，模型由 Harness 现有登录态调用。
