#!/usr/bin/env python3
"""生成 questions.csv，并逐条执行 golden SQL 验证可运行。

用法：
  python scenario/build_questions.py --db scenario/anticheat.db
"""

import argparse
import csv
import sqlite3
import sys
from pathlib import Path

QUESTIONS = [
    {
        "id": "Q01",
        "category": "规模",
        "difficulty": "easy",
        "skill": "多表联结+聚合",
        "question": "上周（2026-10-26 至 2026-11-01）各城市已送达订单的净 GMV 与订单数，按净 GMV 降序。",
        "expect_columns": "city|orders|net_gmv",
        "golden_sql": """SELECT u.city AS city,
       COUNT(*) AS orders,
       ROUND(SUM(o.pay_amt - o.refund_amt), 2) AS net_gmv
FROM orders o
JOIN users u ON u.user_id = o.user_id
WHERE o.order_ts >= '2026-10-26' AND o.order_ts < '2026-11-02'
  AND o.status = 'delivered'
GROUP BY u.city
ORDER BY net_gmv DESC;""",
    },
    {
        "id": "Q02",
        "category": "规模",
        "difficulty": "easy",
        "skill": "聚合",
        "question": "上周（2026-10-26 至 2026-11-01）整体客单价（净 GMV ÷ 已送达订单数），保留两位小数。",
        "expect_columns": "aov",
        "golden_sql": """SELECT ROUND(SUM(pay_amt - refund_amt) * 1.0 / COUNT(*), 2) AS aov
FROM orders
WHERE order_ts >= '2026-10-26' AND order_ts < '2026-11-02'
  AND status = 'delivered';""",
    },
    {
        "id": "Q03",
        "category": "规模",
        "difficulty": "easy",
        "skill": "日期分组",
        "question": "2026 年 10 月每天的订单量，按日期升序。",
        "expect_columns": "d|orders",
        "golden_sql": """SELECT substr(order_ts, 1, 10) AS d, COUNT(*) AS orders
FROM orders
WHERE order_ts >= '2026-10-01' AND order_ts < '2026-11-01'
GROUP BY d
ORDER BY d;""",
    },
    {
        "id": "Q04",
        "category": "新客",
        "difficulty": "medium",
        "skill": "条件聚合",
        "question": "上周各城市新客订单占比（new_user=1 的订单数 ÷ 已送达订单数），保留四位小数，按占比降序。",
        "expect_columns": "city|new_user_orders|new_ratio",
        "golden_sql": """SELECT u.city AS city,
       SUM(CASE WHEN o.is_new_user = 1 THEN 1 ELSE 0 END) AS new_user_orders,
       ROUND(SUM(CASE WHEN o.is_new_user = 1 THEN 1.0 ELSE 0 END) / COUNT(*), 4) AS new_ratio
FROM orders o
JOIN users u ON u.user_id = o.user_id
WHERE o.order_ts >= '2026-10-26' AND o.order_ts < '2026-11-02'
  AND o.status = 'delivered'
GROUP BY u.city
ORDER BY new_ratio DESC;""",
    },
    {
        "id": "Q05",
        "category": "新客",
        "difficulty": "hard",
        "skill": "子查询+时间窗",
        "question": "2026-10-01 至 2026-10-25 注册的用户中，注册后 7 天内下过单的人数与比例（比例保留四位小数）。",
        "expect_columns": "new_users|ordered_7d|rate",
        "golden_sql": """WITH cohort AS (
  SELECT * FROM users
  WHERE signup_ts >= '2026-10-01' AND signup_ts < '2026-10-26'
),
first7 AS (
  SELECT DISTINCT u.user_id
  FROM cohort u
  JOIN orders o ON o.user_id = u.user_id
   AND o.order_ts >= u.signup_ts
   AND o.order_ts < datetime(u.signup_ts, '+7 days')
)
SELECT (SELECT COUNT(*) FROM cohort) AS new_users,
       (SELECT COUNT(*) FROM first7) AS ordered_7d,
       ROUND((SELECT COUNT(*) FROM first7) * 1.0 / (SELECT COUNT(*) FROM cohort), 4) AS rate;""",
    },
    {
        "id": "Q06",
        "category": "新客",
        "difficulty": "medium",
        "skill": "分组后二次聚合",
        "question": "上周下过已送达订单的用户中，复购（≥2 单）人数与复购率（保留四位小数）。",
        "expect_columns": "buyers|repeat_buyers|repeat_rate",
        "golden_sql": """WITH per_user AS (
  SELECT user_id, COUNT(*) AS n
  FROM orders
  WHERE order_ts >= '2026-10-26' AND order_ts < '2026-11-02'
    AND status = 'delivered'
  GROUP BY user_id
)
SELECT COUNT(*) AS buyers,
       SUM(CASE WHEN n >= 2 THEN 1 ELSE 0 END) AS repeat_buyers,
       ROUND(SUM(CASE WHEN n >= 2 THEN 1.0 ELSE 0 END) / COUNT(*), 4) AS repeat_rate
FROM per_user;""",
    },
    {
        "id": "Q07",
        "category": "优惠券",
        "difficulty": "medium",
        "skill": "条件聚合",
        "question": "各优惠券活动的领券数、核销数、核销率（保留四位小数），按核销率降序。",
        "expect_columns": "campaign|issued|used|use_rate",
        "golden_sql": """SELECT campaign,
       COUNT(*) AS issued,
       SUM(CASE WHEN used_ts IS NOT NULL THEN 1 ELSE 0 END) AS used,
       ROUND(SUM(CASE WHEN used_ts IS NOT NULL THEN 1.0 ELSE 0 END) / COUNT(*), 4) AS use_rate
FROM coupons
GROUP BY campaign
ORDER BY use_rate DESC;""",
    },
    {
        "id": "Q08",
        "category": "优惠券",
        "difficulty": "hard",
        "skill": "时间差+联结",
        "question": "领券后 60 秒内核销、且该订单已退款的用户数（券滥用嫌疑规模）。",
        "expect_columns": "users",
        "golden_sql": """SELECT COUNT(DISTINCT c.user_id) AS users
FROM coupons c
JOIN orders o ON o.order_id = c.order_id
WHERE c.used_ts IS NOT NULL
  AND (julianday(c.used_ts) - julianday(c.issued_ts)) * 86400 < 60
  AND o.status = 'refunded';""",
    },
    {
        "id": "Q09",
        "category": "优惠券",
        "difficulty": "medium",
        "skill": "联结+聚合",
        "question": "各活动已核销订单的优惠金额占 GMV 比例（保留四位小数），按比例降序。",
        "expect_columns": "campaign|orders|discount_share",
        "golden_sql": """SELECT c.campaign AS campaign,
       COUNT(*) AS orders,
       ROUND(SUM(o.discount_amt) / SUM(o.gmv), 4) AS discount_share
FROM coupons c
JOIN orders o ON o.order_id = c.order_id
WHERE c.used_ts IS NOT NULL
GROUP BY c.campaign
ORDER BY discount_share DESC;""",
    },
    {
        "id": "Q10",
        "category": "设备",
        "difficulty": "easy",
        "skill": "分组+HAVING",
        "question": "关联账号数 ≥3 的设备及其账号数，按账号数降序、设备 ID 升序。",
        "expect_columns": "device_id|users",
        "golden_sql": """SELECT device_id, COUNT(DISTINCT user_id) AS users
FROM devices
GROUP BY device_id
HAVING COUNT(DISTINCT user_id) >= 3
ORDER BY users DESC, device_id;""",
    },
    {
        "id": "Q11",
        "category": "设备",
        "difficulty": "medium",
        "skill": "条件去重",
        "question": "设备 D900001 与 D900002 一共关联多少账号，其中 2026-10-01 及以后注册的新账号多少。",
        "expect_columns": "users|new_users",
        "golden_sql": """SELECT COUNT(DISTINCT d.user_id) AS users,
       COUNT(DISTINCT CASE WHEN u.signup_ts >= '2026-10-01' THEN d.user_id END) AS new_users
FROM devices d
JOIN users u ON u.user_id = d.user_id
WHERE d.device_id IN ('D900001', 'D900002');""",
    },
    {
        "id": "Q12",
        "category": "设备",
        "difficulty": "medium",
        "skill": "分组+HAVING",
        "question": "同一下单 IP、同一天出现 ≥5 个不同账号的“IP-日”组合数。",
        "expect_columns": "ip_days",
        "golden_sql": """SELECT COUNT(*) AS ip_days
FROM (
  SELECT order_ip, substr(order_ts, 1, 10) AS d
  FROM orders
  WHERE order_ip IS NOT NULL AND order_ip <> ''
  GROUP BY order_ip, d
  HAVING COUNT(DISTINCT user_id) >= 5
);""",
    },
    {
        "id": "Q13",
        "category": "设备",
        "difficulty": "medium",
        "skill": "子查询+平均",
        "question": "各城市用户的平均关联设备数（保留两位小数），按均值降序。",
        "expect_columns": "city|avg_devices",
        "golden_sql": """SELECT u.city AS city, ROUND(AVG(d.cnt), 2) AS avg_devices
FROM users u
JOIN (
  SELECT user_id, COUNT(DISTINCT device_id) AS cnt
  FROM devices
  GROUP BY user_id
) d ON d.user_id = u.user_id
GROUP BY u.city
ORDER BY avg_devices DESC;""",
    },
    {
        "id": "Q14",
        "category": "骑手",
        "difficulty": "medium",
        "skill": "LEFT JOIN+聚合",
        "question": "上周各城市骑手人均完成单量（已送达订单数 ÷ 有记录的骑手数，保留两位小数），按人均降序。",
        "expect_columns": "city|riders|orders|avg_orders",
        "golden_sql": """SELECT r.city AS city,
       COUNT(DISTINCT r.rider_id) AS riders,
       COUNT(o.order_id) AS orders,
       ROUND(COUNT(o.order_id) * 1.0 / COUNT(DISTINCT r.rider_id), 2) AS avg_orders
FROM riders r
LEFT JOIN orders o ON o.rider_id = r.rider_id
  AND o.status = 'delivered'
  AND o.order_ts >= '2026-10-26' AND o.order_ts < '2026-11-02'
GROUP BY r.city
ORDER BY avg_orders DESC;""",
    },
    {
        "id": "Q15",
        "category": "骑手",
        "difficulty": "medium",
        "skill": "HAVING+排序",
        "question": "订单量 ≥20 的骑手中，取消率最高的 10 位（取消率保留四位小数，按取消率降序、订单数降序）。",
        "expect_columns": "rider_id|orders|cancel_rate",
        "golden_sql": """SELECT rider_id,
       COUNT(*) AS orders,
       ROUND(SUM(CASE WHEN status = 'cancelled' THEN 1.0 ELSE 0 END) / COUNT(*), 4) AS cancel_rate
FROM orders
GROUP BY rider_id
HAVING COUNT(*) >= 20
ORDER BY cancel_rate DESC, orders DESC
LIMIT 10;""",
    },
    {
        "id": "Q16",
        "category": "骑手",
        "difficulty": "medium",
        "skill": "多表联结",
        "question": "骑手常用设备同时被某个用户账号使用的“骑手-账号”对数。",
        "expect_columns": "pairs",
        "golden_sql": """SELECT COUNT(*) AS pairs
FROM riders r
JOIN devices d ON d.device_id = r.device_id
WHERE r.device_id IS NOT NULL AND r.device_id <> '';""",
    },
    {
        "id": "Q17",
        "category": "骑手",
        "difficulty": "hard",
        "skill": "三表联结",
        "question": "由“与该用户共用设备”的骑手配送的订单数（自交易嫌疑订单）。",
        "expect_columns": "orders",
        "golden_sql": """SELECT COUNT(*) AS orders
FROM orders o
JOIN riders r ON r.rider_id = o.rider_id
JOIN devices d ON d.device_id = r.device_id AND d.user_id = o.user_id
WHERE r.device_id IS NOT NULL AND r.device_id <> '';""",
    },
    {
        "id": "Q18",
        "category": "商家",
        "difficulty": "medium",
        "skill": "条件聚合",
        "question": "订单量 ≥50 的商家中，退款率最高的 10 家（退款率保留四位小数，按退款率降序、订单数降序）。",
        "expect_columns": "merchant_id|orders|refund_rate",
        "golden_sql": """SELECT merchant_id,
       COUNT(*) AS orders,
       ROUND(SUM(CASE WHEN status = 'refunded' THEN 1.0 ELSE 0 END) / COUNT(*), 4) AS refund_rate
FROM orders
GROUP BY merchant_id
HAVING COUNT(*) >= 50
ORDER BY refund_rate DESC, orders DESC
LIMIT 10;""",
    },
    {
        "id": "Q19",
        "category": "商家",
        "difficulty": "easy",
        "skill": "聚合+排序",
        "question": "退款金额最高的 5 家商家及其退款金额（保留两位小数）。",
        "expect_columns": "merchant_id|refund_amt",
        "golden_sql": """SELECT merchant_id, ROUND(SUM(refund_amt), 2) AS refund_amt
FROM orders
GROUP BY merchant_id
ORDER BY refund_amt DESC
LIMIT 5;""",
    },
    {
        "id": "Q20",
        "category": "商家",
        "difficulty": "medium",
        "skill": "联结+占比",
        "question": "各商家品类的 GMV 与占全部订单 GMV 的比例（比例保留四位小数），按 GMV 降序。",
        "expect_columns": "category|gmv|share",
        "golden_sql": """SELECT m.category AS category,
       ROUND(SUM(o.gmv), 2) AS gmv,
       ROUND(SUM(o.gmv) / (SELECT SUM(gmv) FROM orders), 4) AS share
FROM orders o
JOIN merchants m ON m.merchant_id = o.merchant_id
GROUP BY m.category
ORDER BY gmv DESC;""",
    },
    {
        "id": "Q21",
        "category": "作弊特征",
        "difficulty": "hard",
        "skill": "分组+HAVING+子查询",
        "question": "存在“同一用户、同一小时 ≥8 单”的用户数与涉及订单数。",
        "expect_columns": "users|orders",
        "golden_sql": """SELECT COUNT(DISTINCT user_id) AS users, SUM(n) AS orders
FROM (
  SELECT user_id, substr(order_ts, 1, 13) AS h, COUNT(*) AS n
  FROM orders
  GROUP BY user_id, h
  HAVING COUNT(*) >= 8
);""",
    },
    {
        "id": "Q22",
        "category": "作弊特征",
        "difficulty": "easy",
        "skill": "分组+HAVING",
        "question": "退款订单数 ≥3 的用户数。",
        "expect_columns": "users",
        "golden_sql": """SELECT COUNT(*) AS users
FROM (
  SELECT user_id
  FROM orders
  WHERE status = 'refunded'
  GROUP BY user_id
  HAVING COUNT(*) >= 3
);""",
    },
    {
        "id": "Q23",
        "category": "作弊特征",
        "difficulty": "hard",
        "skill": "CTE+UNION",
        "question": "三类作弊嫌疑（多账号设备、60 秒券滥用、小时频次 ≥8）合并去重后的用户数。",
        "expect_columns": "users",
        "golden_sql": """WITH multi AS (
  SELECT DISTINCT d.user_id
  FROM devices d
  JOIN (
    SELECT device_id
    FROM devices
    GROUP BY device_id
    HAVING COUNT(DISTINCT user_id) >= 3
  ) x ON x.device_id = d.device_id
),
coupon AS (
  SELECT DISTINCT c.user_id
  FROM coupons c
  JOIN orders o ON o.order_id = c.order_id
  WHERE c.used_ts IS NOT NULL
    AND (julianday(c.used_ts) - julianday(c.issued_ts)) * 86400 < 60
    AND o.status = 'refunded'
),
vel AS (
  SELECT DISTINCT user_id
  FROM (
    SELECT user_id
    FROM orders
    GROUP BY user_id, substr(order_ts, 1, 13)
    HAVING COUNT(*) >= 8
  )
)
SELECT COUNT(*) AS users
FROM (
  SELECT user_id FROM multi
  UNION
  SELECT user_id FROM coupon
  UNION
  SELECT user_id FROM vel
);""",
    },
    {
        "id": "Q24",
        "category": "策略评估",
        "difficulty": "hard",
        "skill": "CTE+LEFT JOIN+CASE",
        "question": "设备 D900001/D900002 关联账号在 2026-10-18 至 10-24（处置前）与 10-25 至 10-31（处置后）的订单数与下单用户数对比，按时间顺序输出。",
        "expect_columns": "period|orders|users",
        "golden_sql": """WITH farm AS (
  SELECT DISTINCT d.user_id
  FROM devices d
  WHERE d.device_id IN ('D900001', 'D900002')
),
periods(period, start_ts, end_ts, ord) AS (
  VALUES ('处置前', '2026-10-18', '2026-10-25', 1),
         ('处置后', '2026-10-25', '2026-11-01', 2)
)
SELECT p.period AS period,
       COUNT(o.order_id) AS orders,
       COUNT(DISTINCT o.user_id) AS users
FROM periods p
LEFT JOIN orders o ON o.user_id IN (SELECT user_id FROM farm)
  AND o.order_ts >= p.start_ts AND o.order_ts < p.end_ts
GROUP BY p.period, p.ord
ORDER BY p.ord;""",
    },
]


def main():
    ap = argparse.ArgumentParser(description="生成并验证 questions.csv")
    ap.add_argument("--db", default=str(Path(__file__).with_name("anticheat.db")))
    ap.add_argument("--out", default=str(Path(__file__).with_name("questions.csv")))
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        raise SystemExit("数据库不存在：%s" % db)

    conn = sqlite3.connect(str(db))
    failures = []
    for q in QUESTIONS:
        try:
            cur = conn.execute(q["golden_sql"])
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description]
        except sqlite3.Error as exc:
            failures.append((q["id"], str(exc)))
            print("%s FAIL %s" % (q["id"], exc))
            continue
        expect = [c.strip() for c in q["expect_columns"].split("|")]
        if [c.lower() for c in cols] != [c.lower() for c in expect]:
            failures.append((q["id"], "列名不匹配：%s != %s" % (cols, expect)))
            print("%s FAIL 列名 %s != %s" % (q["id"], cols, expect))
            continue
        print("%s ok rows=%d cols=%s" % (q["id"], len(rows), ",".join(cols)))
    conn.close()

    if failures:
        print("\n有 %d 条 golden 失败，未写出 CSV。" % len(failures))
        sys.exit(1)

    with open(args.out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(
            f,
            fieldnames=["id", "question", "golden_sql", "expect_columns",
                        "difficulty", "skill", "category"],
        )
        w.writeheader()
        for q in QUESTIONS:
            w.writerow({k: q[k] for k in w.fieldnames})
    print("\n写出 %s（%d 条）" % (args.out, len(QUESTIONS)))


if __name__ == "__main__":
    main()
