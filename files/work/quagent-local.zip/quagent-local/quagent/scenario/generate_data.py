#!/usr/bin/env python3
"""生成合成海外外卖反作弊库（SQLite）。

数据全部为合成数据，不代表任何真实公司或用户。
固定种子可复现；五类作弊模式写入 labels.csv，仅用于评测。

用法：
  python scenario/generate_data.py --db scenario/anticheat.db --seed 20261105
"""

import argparse
import bisect
import csv
import json
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

CITIES = [
    ("Singapore", "SG", 0.24),
    ("Bangkok", "TH", 0.22),
    ("Kuala Lumpur", "MY", 0.16),
    ("Jakarta", "ID", 0.18),
    ("Ho Chi Minh City", "VN", 0.12),
    ("Manila", "PH", 0.08),
]
CATEGORIES = ["快餐", "饮品", "甜品", "正餐", "超市"]
OS_TYPES = ["iOS", "Android"]
EVENT_TYPES = ["app_open", "browse", "add_cart", "checkout", "pay"]
EVENT_WEIGHTS = [0.40, 0.30, 0.15, 0.10, 0.05]
HOUR_WEIGHTS = [
    0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.3, 0.5, 0.6, 0.7,
    1.0, 2.0, 3.0, 3.0, 1.5, 1.0, 1.0, 1.5, 2.5, 3.0,
    2.5, 1.5, 0.8, 0.4,
]

DATA_START = datetime(2026, 10, 5)
DATA_END = datetime(2026, 11, 2)
REFERENCE_END = "2026-11-02"

USER_BASE = 4720
USER_VELOCITY = (4721, 4800)
USER_COLLUSION = (4801, 4820)
USER_COUPON = (4821, 4970)
USER_FARM = (4971, 5000)

MERCHANT_COUNT = 300
RIDER_COUNT = 400
BASE_ORDERS = 59000
COUPON_COUNT = 20000
EVENT_COUNT = 120000


def cum_weights(weights):
    out, acc = [], 0.0
    for w in weights:
        acc += w
        out.append(acc)
    return out


def weighted_pick(rng, items, cum, total):
    return items[bisect.bisect_left(cum, rng.random() * total)]


def ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def uid(n):
    return "U%06d" % n


def oid(n):
    return "O%06d" % n


def did(n):
    return "D%06d" % n


def rid(n):
    return "R%03d" % n


def mid(n):
    return "M%03d" % n


def pick_city(rng, city_weights=None):
    weights = city_weights or [c[2] for c in CITIES]
    return rng.choices([c[0] for c in CITIES], weights=weights, k=1)[0]


def city_country(city):
    return next(c[1] for c in CITIES if c[0] == city)


def random_order_time(rng, start=DATA_START, end=DATA_END):
    total_seconds = int((end - start).total_seconds())
    day = rng.randrange(0, max(1, total_seconds // 86400))
    hour = rng.choices(range(24), weights=HOUR_WEIGHTS, k=1)[0]
    base = start + timedelta(days=day, hours=hour,
                             minutes=rng.randrange(60), seconds=rng.randrange(60))
    if base >= end:
        base = end - timedelta(minutes=rng.randrange(1, 600))
    return base


def random_ip(rng, city):
    city_idx = [c[0] for c in CITIES].index(city) + 1
    return "182.%d.%d.%d" % (city_idx, rng.randrange(1, 255), rng.randrange(1, 255))


def make_schema(conn):
    conn.executescript(
        """
        CREATE TABLE users (
          user_id TEXT PRIMARY KEY,
          city TEXT NOT NULL,
          country TEXT NOT NULL,
          signup_ts TEXT NOT NULL,
          user_level TEXT NOT NULL CHECK (user_level IN ('new','normal','vip'))
        );
        CREATE TABLE devices (
          device_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          os TEXT NOT NULL,
          first_seen_ts TEXT NOT NULL,
          last_seen_ts TEXT NOT NULL,
          ip_city TEXT,
          PRIMARY KEY (device_id, user_id)
        );
        CREATE TABLE riders (
          rider_id TEXT PRIMARY KEY,
          city TEXT NOT NULL,
          signup_ts TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('active','inactive')),
          device_id TEXT
        );
        CREATE TABLE merchants (
          merchant_id TEXT PRIMARY KEY,
          city TEXT NOT NULL,
          category TEXT NOT NULL,
          signup_ts TEXT NOT NULL
        );
        CREATE TABLE orders (
          order_id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          rider_id TEXT,
          merchant_id TEXT NOT NULL,
          city TEXT NOT NULL,
          order_ts TEXT NOT NULL,
          delivered_ts TEXT,
          status TEXT NOT NULL CHECK (status IN ('delivered','cancelled','refunded','undelivered')),
          gmv REAL NOT NULL,
          discount_amt REAL NOT NULL DEFAULT 0,
          pay_amt REAL NOT NULL,
          refund_amt REAL NOT NULL DEFAULT 0,
          is_new_user INTEGER NOT NULL DEFAULT 0,
          order_ip TEXT
        );
        CREATE TABLE events (
          event_id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          device_id TEXT,
          event_type TEXT NOT NULL,
          event_ts TEXT NOT NULL,
          ip TEXT,
          city TEXT
        );
        CREATE TABLE coupons (
          coupon_id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          issued_ts TEXT NOT NULL,
          used_ts TEXT,
          order_id TEXT,
          discount_amt REAL NOT NULL,
          campaign TEXT NOT NULL
        );
        CREATE INDEX idx_orders_user_ts ON orders(user_id, order_ts);
        CREATE INDEX idx_orders_ts ON orders(order_ts);
        CREATE INDEX idx_orders_merchant ON orders(merchant_id);
        CREATE INDEX idx_orders_rider ON orders(rider_id);
        CREATE INDEX idx_devices_device ON devices(device_id);
        CREATE INDEX idx_coupons_user ON coupons(user_id);
        CREATE INDEX idx_events_user_ts ON events(user_id, event_ts);
        """
    )


def build_users(rng):
    users = []
    for n in range(1, USER_BASE + 1):
        city = pick_city(rng, [c[2] for c in CITIES])
        # 两成用户为 10 月新注册，供新客漏斗题使用
        if rng.random() < 0.20:
            signup = datetime(2026, 10, 1) + timedelta(
                days=rng.randrange(0, 24), hours=rng.randrange(24), minutes=rng.randrange(60)
            )
        else:
            signup = datetime(2026, 6, 1) + timedelta(
                days=rng.randrange(0, 120), hours=rng.randrange(24), minutes=rng.randrange(60)
            )
        level = rng.choices(["new", "normal", "vip"], weights=[0.2, 0.7, 0.1], k=1)[0]
        users.append([uid(n), city, city_country(city), ts(signup), level])

    planted = []
    for n in range(USER_VELOCITY[0], USER_VELOCITY[1] + 1):
        city = pick_city(rng)
        planted.append([uid(n), city, city_country(city), "2026-09-20 10:00:00", "normal"])
    for n in range(USER_COLLUSION[0], USER_COLLUSION[1] + 1):
        city = pick_city(rng)
        planted.append([uid(n), city, city_country(city), "2026-08-15 10:00:00", "normal"])
    for n in range(USER_COUPON[0], USER_COUPON[1] + 1):
        city = pick_city(rng)
        planted.append([uid(n), city, city_country(city), "2026-07-01 10:00:00", "normal"])
    for n in range(USER_FARM[0], USER_FARM[1] + 1):
        city = "Singapore" if n % 2 == 0 else "Bangkok"
        planted.append([uid(n), city, city_country(city), "2026-10-15 09:00:00", "new"])
    users.extend(planted)
    return users


def build_devices(rng, users):
    devices = []
    primary = {}
    n = 1
    for user in users:
        count = 2 if rng.random() < 0.15 else 1
        for _ in range(count):
            device_id = did(n)
            n += 1
            first = rng.choice(
                [datetime(2026, 7, 1), datetime(2026, 8, 15), datetime(2026, 9, 1)]
            ) + timedelta(days=rng.randrange(60), hours=rng.randrange(24))
            first_s = ts(first)
            last_s = ts(DATA_END - timedelta(hours=rng.randrange(1, 72)))
            devices.append([device_id, user[0], rng.choice(OS_TYPES), first_s, last_s, user[1]])
            primary.setdefault(user[0], device_id)
    return devices, primary, n


def build_riders(rng):
    riders = []
    for n in range(1, RIDER_COUNT + 1):
        city = pick_city(rng)
        signup = datetime(2026, 3, 1) + timedelta(days=rng.randrange(240), hours=rng.randrange(24))
        status = "active" if rng.random() < 0.95 else "inactive"
        riders.append([rid(n), city, ts(signup), status, None])
    return riders


def build_merchants(rng):
    merchants = []
    for n in range(1, MERCHANT_COUNT + 1):
        city = pick_city(rng)
        signup = datetime(2026, 1, 1) + timedelta(days=rng.randrange(300), hours=rng.randrange(24))
        merchants.append([mid(n), city, rng.choice(CATEGORIES), ts(signup)])
    return merchants


def make_order(rng, seq, user, signup_map, riders_by_city, merchants_by_city,
               status=None, order_dt=None, gmv=None, discount=None, refund=None,
               rider_id=None, ip=None):
    city = user[1]
    if merchants_by_city[city]:
        merchant = rng.choice(merchants_by_city[city])
    else:
        merchant = rng.choice([m for m in merchants_by_city.values() if m])[0]
    rider = rider_id or (
        rng.choice(riders_by_city[city]) if riders_by_city[city]
        else rng.choice([r for r in riders_by_city.values() if r])[0]
    )
    order_dt = order_dt or random_order_time(rng)
    if order_dt < signup_map[user[0]] + timedelta(hours=2):
        order_dt = signup_map[user[0]] + timedelta(hours=2, minutes=rng.randrange(120))
    if gmv is None:
        gmv = round(min(80.0, max(3.0, rng.lognormvariate(3.1, 0.55))), 2)
    if discount is None:
        discount = round(rng.uniform(0.5, 5.0), 2) if rng.random() < 0.30 else 0.0
    discount = min(discount, round(gmv - 0.01, 2))
    pay = round(max(0.01, gmv - discount), 2)
    st = status or rng.choices(
        ["delivered", "cancelled", "refunded", "undelivered"],
        weights=[0.88, 0.07, 0.04, 0.01], k=1)[0]
    delivered = ts(order_dt + timedelta(minutes=rng.randrange(20, 70))) if st == "delivered" else None
    if refund is None:
        refund_amt = pay if st == "refunded" else 0.0
    else:
        refund_amt = min(refund, pay)
    is_new = 1 if order_dt < signup_map[user[0]] + timedelta(days=7) else 0
    return [oid(seq), user[0], rider, merchant[0], city, ts(order_dt), delivered,
            st, gmv, discount, pay, round(refund_amt, 2), is_new, ip or random_ip(rng, city)]


def build_base_orders(rng, users, signup_map, riders_by_city, merchants_by_city):
    orders = []
    user_orders = {u[0]: [] for u in users}
    active = [u for u in users if rng.random() < 0.65]
    weights = [rng.uniform(1, 20) for _ in active]
    cum = cum_weights(weights)
    total = cum[-1]
    seq = 1
    for _ in range(BASE_ORDERS):
        user = weighted_pick(rng, active, cum, total)
        row = make_order(rng, seq, user, signup_map, riders_by_city, merchants_by_city)
        orders.append(row)
        user_orders[user[0]].append(row)
        seq += 1
    return orders, user_orders, seq


def add_refund_ring(rng, orders, user_pool, signup_map, riders_by_city, merchants_by_city,
                    merchants, seq):
    ring_merchants = [mid(n) for n in range(MERCHANT_COUNT - 3, MERCHANT_COUNT + 1)]
    for merchant_id in ring_merchants:
        city = next(x[1] for x in merchants if x[0] == merchant_id)
        candidates = [u for u in user_pool if u[1] == city][:40] or user_pool[:40]
        for i in range(60):
            user = rng.choice(candidates)
            st = "refunded" if i < 24 else rng.choice(["delivered", "delivered", "cancelled"])
            row = make_order(rng, seq, user, signup_map, riders_by_city, merchants_by_city, status=st)
            row[3] = merchant_id
            orders.append(row)
            seq += 1
    return seq, ring_merchants


def add_velocity(rng, orders, user_map, signup_map, riders_by_city, merchants_by_city, seq):
    users = [user_map[uid(n)] for n in range(USER_VELOCITY[0], USER_VELOCITY[1] + 1)]
    for user in users:
        day = datetime(2026, 10, 6) + timedelta(days=rng.randrange(0, 24))
        hour = rng.randrange(9, 23)
        start = day.replace(hour=hour, minute=rng.randrange(0, 20), second=0)
        for i in range(8):
            row = make_order(
                rng, seq, user, signup_map, riders_by_city, merchants_by_city,
                status="delivered", order_dt=start + timedelta(minutes=i * 4 + rng.randrange(0, 3)))
            orders.append(row)
            seq += 1
    return seq


def add_collusion(rng, orders, users, signup_map, riders, devices, primary,
                  riders_by_city, merchants_by_city, seq):
    pairs = []
    for i in range(20):
        rider = riders[i]
        rider[4] = "D910%03d" % (i + 1)
        user = users[USER_COLLUSION[0] - 1 + i]
        devices.append(["D910%03d" % (i + 1), user[0], rng.choice(OS_TYPES),
                        "2026-10-01 08:00:00", "2026-11-01 20:00:00", user[1]])
        primary[user[0]] = "D910%03d" % (i + 1)
        day = datetime(2026, 10, 10) + timedelta(days=rng.randrange(0, 18))
        for j in range(5):
            row = make_order(
                rng, seq, user, signup_map, {c[0]: [rider[0]] for c in CITIES}, merchants_by_city,
                status="delivered",
                order_dt=day.replace(hour=rng.randrange(11, 22), minute=rng.randrange(60), second=0),
                rider_id=rider[0])
            orders.append(row)
            seq += 1
        pairs.append((rider[0], user[0]))
    return seq, pairs


def add_coupon_abuse(rng, orders, user_map, signup_map, riders_by_city, merchants_by_city,
                     coupons, seq, coupon_seq):
    users = [user_map[uid(n)] for n in range(USER_COUPON[0], USER_COUPON[1] + 1)]
    for user in users:
        day = datetime(2026, 10, 12) + timedelta(days=rng.randrange(0, 19))
        order_dt = day.replace(hour=rng.randrange(9, 23), minute=rng.randrange(60), second=0)
        row = make_order(
            rng, seq, user, signup_map, riders_by_city, merchants_by_city,
            status="refunded", order_dt=order_dt, gmv=round(rng.uniform(8, 16), 2),
            discount=round(rng.uniform(5, 7), 2))
        orders.append(row)
        coupon_seq += 1
        coupons.append(["C9%05d" % coupon_seq, user[0],
                        ts(order_dt - timedelta(seconds=rng.randrange(40, 59))),
                        ts(order_dt), row[0], float(row[9]), "festival"])
        seq += 1
    return seq, coupon_seq


def add_device_farm(rng, orders, users, signup_map, riders_by_city, merchants_by_city,
                    devices, primary, seq):
    farm = [u for u in users if USER_FARM[0] <= int(u[0][1:]) <= USER_FARM[1]]
    for i, user in enumerate(farm):
        device_id = "D900001" if i < 15 else "D900002"
        devices.append([device_id, user[0], "Android", "2026-10-15 09:00:00",
                        "2026-10-24 23:00:00", user[1]])
        primary[user[0]] = device_id
    ip_by_city = {"Singapore": "103.21.244.17", "Bangkok": "103.21.244.18"}
    for i, user in enumerate(farm):
        ip = ip_by_city[user[1]]
        for j in range(10):
            day = datetime(2026, 10, 18) + timedelta(days=rng.randrange(0, 7))
            order_dt = day.replace(hour=rng.randrange(11, 24), minute=rng.randrange(60), second=0)
            row = make_order(
                rng, seq, user, signup_map, riders_by_city, merchants_by_city,
                status="delivered", order_dt=order_dt,
                gmv=round(rng.uniform(5, 15), 2), discount=round(rng.uniform(2, 5), 2), ip=ip)
            orders.append(row)
            seq += 1
    return seq


def build_normal_coupons(rng, orders, user_orders, signup_map):
    coupons = []
    used_candidates = []
    for row in orders:
        if row[10] > 0 and row[0] and row[1] in user_orders:
            used_candidates.append(row)
    rng.shuffle(used_candidates)
    used_candidates = used_candidates[:int(COUPON_COUNT * 0.55)]
    for row in used_candidates:
        order_dt = datetime.strptime(row[5], "%Y-%m-%d %H:%M:%S")
        discount = row[9]
        if discount <= 0:
            discount = round(rng.uniform(1, 5), 2)
            row[9] = discount
            row[10] = round(max(0.01, row[8] - discount), 2)
            if row[7] == "refunded":
                row[11] = row[10]
        issued = order_dt - timedelta(hours=rng.uniform(2, 72))
        used = order_dt - timedelta(minutes=rng.uniform(2, 25))
        coupons.append(["C%05d" % (len(coupons) + 1), row[1], ts(issued), ts(used),
                        row[0], float(discount),
                        rng.choices(["new_user", "festival", "retention"], weights=[0.4, 0.35, 0.25])[0]])
    user_ids = list(user_orders.keys())
    while len(coupons) < COUPON_COUNT:
        user_id = rng.choice(user_ids)
        if not user_orders[user_id]:
            continue
        row = rng.choice(user_orders[user_id])
        order_dt = datetime.strptime(row[5], "%Y-%m-%d %H:%M:%S")
        issued = order_dt - timedelta(hours=rng.uniform(2, 72))
        use = rng.random() < 0.55
        coupons.append(["C%05d" % (len(coupons) + 1), user_id, ts(issued),
                        ts(order_dt - timedelta(minutes=rng.uniform(2, 25))) if use else None,
                        row[0] if use else None,
                        round(rng.uniform(1, 5), 2),
                        rng.choices(["new_user", "festival", "retention"], weights=[0.4, 0.35, 0.25])[0]])
    return coupons


def build_events(rng, users, primary, signup_map):
    events = []
    weights = [rng.uniform(1, 12) for _ in users]
    cum = cum_weights(weights)
    total = cum[-1]
    for i in range(1, EVENT_COUNT + 1):
        user = weighted_pick(rng, users, cum, total)
        dt = random_order_time(rng)
        if dt < signup_map[user[0]]:
            dt = signup_map[user[0]] + timedelta(minutes=rng.randrange(1, 600))
        events.append(["E%07d" % i, user[0], primary.get(user[0]),
                       rng.choices(EVENT_TYPES, weights=EVENT_WEIGHTS, k=1)[0],
                       ts(dt), random_ip(rng, user[1]), user[1]])
    return events


def write_labels(path, farm_users, devices, coupon_users, pairs, ring_merchants, velocity_users):
    rows = []
    for u in farm_users:
        rows.append(["device_farm", "user", u, "30 个新账号共用 2 台设备"])
    for d in devices:
        rows.append(["device_farm", "device", d, "设备农场共用设备"])
    for u in coupon_users:
        rows.append(["coupon_abuse", "user", u, "领券 60 秒内下单并退款"])
    for rider_id, user_id in pairs:
        rows.append(["rider_collusion", "pair", rider_id + "|" + user_id, "骑手与用户共用设备"])
    for m in ring_merchants:
        rows.append(["refund_ring", "merchant", m, "退款率约四成的商家"])
    for u in velocity_users:
        rows.append(["velocity", "user", u, "一小时内下单 8 单"])
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pattern", "entity_type", "entity_id", "note"])
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description="生成合成反作弊库")
    ap.add_argument("--db", default=str(Path(__file__).with_name("anticheat.db")))
    ap.add_argument("--seed", type=int, default=20261105)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    db = Path(args.db)
    if db.exists() and not args.force:
        raise SystemExit("数据库已存在；加 --force 覆盖：%s" % db)

    rng = random.Random(args.seed)

    users = build_users(rng)
    user_map = {u[0]: u for u in users}
    signup_map = {u[0]: datetime.strptime(u[3], "%Y-%m-%d %H:%M:%S") for u in users}

    riders = build_riders(rng)
    merchants = build_merchants(rng)

    riders_by_city = {c[0]: [] for c in CITIES}
    for r in riders:
        riders_by_city[r[1]].append(r[0])
    merchants_by_city = {c[0]: [] for c in CITIES}
    for m in merchants:
        merchants_by_city[m[1]].append(m)

    devices, primary, _ = build_devices(rng, users)

    base_users = users[:USER_BASE]
    ring_ids = {mid(n) for n in range(MERCHANT_COUNT - 3, MERCHANT_COUNT + 1)}
    base_merchants_by_city = {
        city: [m for m in lst if m[0] not in ring_ids]
        for city, lst in merchants_by_city.items()
    }
    orders, user_orders, seq = build_base_orders(
        rng, base_users, signup_map, riders_by_city, base_merchants_by_city)
    seq, ring_merchants = add_refund_ring(
        rng, orders, base_users, signup_map, riders_by_city, merchants_by_city, merchants, seq)
    seq = add_velocity(rng, orders, user_map, signup_map, riders_by_city, merchants_by_city, seq)
    seq, pairs = add_collusion(
        rng, orders, users, signup_map, riders, devices, primary,
        riders_by_city, merchants_by_city, seq)
    coupons = []
    seq, coupon_seq = add_coupon_abuse(
        rng, orders, user_map, signup_map, riders_by_city, merchants_by_city, coupons, seq, 0)
    seq = add_device_farm(
        rng, orders, users, signup_map, riders_by_city, merchants_by_city, devices, primary, seq)

    coupons = build_normal_coupons(rng, orders, user_orders, signup_map) + coupons
    events = build_events(rng, users, primary, signup_map)

    if db.exists():
        db.unlink()
    conn = sqlite3.connect(str(db))
    try:
        make_schema(conn)
        conn.executemany("INSERT INTO users VALUES (?,?,?,?,?)", users)
        conn.executemany("INSERT INTO devices VALUES (?,?,?,?,?,?)", devices)
        conn.executemany("INSERT INTO riders VALUES (?,?,?,?,?)", riders)
        conn.executemany("INSERT INTO merchants VALUES (?,?,?,?)", merchants)
        conn.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", orders)
        conn.executemany("INSERT INTO coupons VALUES (?,?,?,?,?,?,?)", coupons)
        conn.executemany("INSERT INTO events VALUES (?,?,?,?,?,?,?)", events)
        conn.commit()
        counts = {}
        for table in ["users", "devices", "riders", "merchants", "orders", "coupons", "events"]:
            counts[table] = conn.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
    finally:
        conn.close()

    farm_users = [uid(n) for n in range(USER_FARM[0], USER_FARM[1] + 1)]
    coupon_users = [uid(n) for n in range(USER_COUPON[0], USER_COUPON[1] + 1)]
    velocity_users = [uid(n) for n in range(USER_VELOCITY[0], USER_VELOCITY[1] + 1)]
    write_labels(
        Path(__file__).with_name("labels.csv"),
        farm_users, ["D900001", "D900002"], coupon_users, pairs,
        ring_merchants, velocity_users)

    summary = {
        "ok": True,
        "db": str(db),
        "seed": args.seed,
        "data_range": [ts(DATA_START), REFERENCE_END],
        "counts": counts,
        "patterns": {
            "device_farm": {"users": 30, "devices": 2},
            "coupon_abuse": {"users": 150},
            "rider_collusion": {"pairs": len(pairs)},
            "refund_ring": {"merchants": len(ring_merchants)},
            "velocity": {"users": len(velocity_users)},
        },
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
