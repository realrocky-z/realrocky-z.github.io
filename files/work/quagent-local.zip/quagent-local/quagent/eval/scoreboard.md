# 评测记录

- 生成时间：2026-11-09 21:23
- 题库：scenario/questions.csv
- 已作答：1 / 24
- 结果一致：1 / 24（4.2%）

| 题号 | 类别 | 难度 | 技能 | 结果 | 说明 |
| --- | --- | --- | --- | --- | --- |
| Q01 | 规模 | easy | 多表联结+聚合 | 通过 | 列数与结果集一致 |
| Q02 | 规模 | easy | 聚合 | 未作答 | 缺少 answers/Q02.sql |
| Q03 | 规模 | easy | 日期分组 | 未作答 | 缺少 answers/Q03.sql |
| Q04 | 新客 | medium | 条件聚合 | 未作答 | 缺少 answers/Q04.sql |
| Q05 | 新客 | hard | 子查询+时间窗 | 未作答 | 缺少 answers/Q05.sql |
| Q06 | 新客 | medium | 分组后二次聚合 | 未作答 | 缺少 answers/Q06.sql |
| Q07 | 优惠券 | medium | 条件聚合 | 未作答 | 缺少 answers/Q07.sql |
| Q08 | 优惠券 | hard | 时间差+联结 | 未作答 | 缺少 answers/Q08.sql |
| Q09 | 优惠券 | medium | 联结+聚合 | 未作答 | 缺少 answers/Q09.sql |
| Q10 | 设备 | easy | 分组+HAVING | 未作答 | 缺少 answers/Q10.sql |
| Q11 | 设备 | medium | 条件去重 | 未作答 | 缺少 answers/Q11.sql |
| Q12 | 设备 | medium | 分组+HAVING | 未作答 | 缺少 answers/Q12.sql |
| Q13 | 设备 | medium | 子查询+平均 | 未作答 | 缺少 answers/Q13.sql |
| Q14 | 骑手 | medium | LEFT JOIN+聚合 | 未作答 | 缺少 answers/Q14.sql |
| Q15 | 骑手 | medium | HAVING+排序 | 未作答 | 缺少 answers/Q15.sql |
| Q16 | 骑手 | medium | 多表联结 | 未作答 | 缺少 answers/Q16.sql |
| Q17 | 骑手 | hard | 三表联结 | 未作答 | 缺少 answers/Q17.sql |
| Q18 | 商家 | medium | 条件聚合 | 未作答 | 缺少 answers/Q18.sql |
| Q19 | 商家 | easy | 聚合+排序 | 未作答 | 缺少 answers/Q19.sql |
| Q20 | 商家 | medium | 联结+占比 | 未作答 | 缺少 answers/Q20.sql |
| Q21 | 作弊特征 | hard | 分组+HAVING+子查询 | 未作答 | 缺少 answers/Q21.sql |
| Q22 | 作弊特征 | easy | 分组+HAVING | 未作答 | 缺少 answers/Q22.sql |
| Q23 | 作弊特征 | hard | CTE+UNION | 未作答 | 缺少 answers/Q23.sql |
| Q24 | 策略评估 | hard | CTE+LEFT JOIN+CASE | 未作答 | 缺少 answers/Q24.sql |

> 修正轮次与错误类型由人工补记。规则命中不等于确认作弊。
