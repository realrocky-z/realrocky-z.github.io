#!/usr/bin/env python3
"""对照 golden 评分：执行 answers/*.sql 与 golden_sql，比对列数与结果集。

规则：
- 忽略列别名，只比列数与值；
- golden 带 LIMIT 时按顺序比，否则按多重集合比；
- 数值容差 0.01。

用法：
  python eval/check_answers.py --answers eval/answers --golden scenario/questions.csv
  python eval/check_answers.py --answers eval/answers --golden scenario/questions.csv --write
"""

import argparse
import csv
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT.parent / "workbench"))

import sqlkit  # noqa: E402

TOL = 0.01


def norm(value):
    if value is None:
        return ("null", "")
    if isinstance(value, bool):
        return ("num", float(value))
    if isinstance(value, (int, float)):
        return ("num", float(value))
    return ("str", str(value).strip())


def same_value(a, b):
    ta, va = norm(a)
    tb, vb = norm(b)
    if ta == "null" or tb == "null":
        return ta == tb
    if ta == "num" and tb == "num":
        return abs(va - vb) <= TOL
    return str(va) == str(vb)


def same_row(a, b):
    return len(a) == len(b) and all(same_value(x, y) for x, y in zip(a, b))


def same_rows(a_rows, b_rows, ordered):
    if len(a_rows) != len(b_rows):
        return False
    if ordered:
        return all(same_row(x, y) for x, y in zip(a_rows, b_rows))
    remaining = list(b_rows)
    for row in a_rows:
        for i, other in enumerate(remaining):
            if same_row(row, other):
                remaining.pop(i)
                break
        else:
            return False
    return True


def run_sql(db, sql):
    ok, one, err = sqlkit.guard(sql)
    if not ok:
        return None, None, err
    out, code = sqlkit.run(db, one, limit=1000, timeout=5)
    if code != 0:
        return None, None, out.get("error", "执行失败")
    return out.get("columns", []), out.get("rows", []), ""


def main():
    ap = argparse.ArgumentParser(description="取数 Agent 评测")
    ap.add_argument("--answers", default=str(HERE / "answers"))
    ap.add_argument("--golden", default=str(ROOT / "scenario" / "questions.csv"))
    ap.add_argument("--db", default=str(ROOT / "scenario" / "anticheat.db"))
    ap.add_argument("--write", action="store_true", help="写出 scoreboard.md")
    args = ap.parse_args()

    answers = Path(args.answers)
    questions = list(csv.DictReader(open(args.golden, encoding="utf-8-sig", newline="")))
    results = []
    answered = passed = 0

    for q in questions:
        qid = q["id"]
        path = answers / (qid + ".sql")
        if not path.exists():
            results.append((q, "未作答", "缺少 answers/%s.sql" % qid))
            continue
        answered += 1
        answer_sql = path.read_text(encoding="utf-8").strip()
        if not answer_sql:
            results.append((q, "未作答", "文件为空"))
            continue
        golden_cols, golden_rows, err = run_sql(args.db, q["golden_sql"])
        if err:
            results.append((q, "题库错误", "golden 执行失败：%s" % err))
            continue
        cols, rows, err = run_sql(args.db, answer_sql)
        if err:
            results.append((q, "执行失败", err))
            continue
        expect_cols = [c.strip() for c in q["expect_columns"].split("|") if c.strip()]
        notes = []
        if len(cols) != len(expect_cols):
            notes.append("列数 %d，期望 %d" % (len(cols), len(expect_cols)))
        ordered = "limit" in q["golden_sql"].lower()
        if not same_rows(golden_rows, rows, ordered=ordered):
            notes.append("结果不一致：答案 %d 行，golden %d 行" % (len(rows), len(golden_rows)))
        if notes:
            results.append((q, "不一致", "；".join(notes)))
        else:
            passed += 1
            results.append((q, "通过", "列数与结果集一致"))

    total = len(questions)
    rate = (passed / total) if total else 0.0
    lines = [
        "# 评测记录",
        "",
        "- 生成时间：%s" % datetime.now().strftime("%Y-%m-%d %H:%M"),
        "- 题库：%s" % args.golden,
        "- 已作答：%d / %d" % (answered, total),
        "- 结果一致：%d / %d（%.1f%%）" % (passed, total, rate * 100),
        "",
        "| 题号 | 类别 | 难度 | 技能 | 结果 | 说明 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for q, status, note in results:
        lines.append("| %s | %s | %s | %s | %s | %s |" % (
            q["id"], q["category"], q["difficulty"], q["skill"], status,
            note.replace("|", "\\|")))
    lines.append("")
    lines.append("> 修正轮次与错误类型由人工补记。规则命中不等于确认作弊。")

    report = "\n".join(lines)
    print(report)
    if args.write:
        out = HERE / "scoreboard.md"
        out.write_text(report + "\n", encoding="utf-8")
        print("\n已写出 %s" % out)


if __name__ == "__main__":
    main()
