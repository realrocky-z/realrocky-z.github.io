SELECT city,
       COUNT(DISTINCT order_id) AS orders,
       SUM(pay_amt - refund_amt) AS net_gmv
FROM orders
WHERE status = 'delivered'
  AND order_ts >= '2026-10-26'
  AND order_ts < '2026-11-02'
GROUP BY city
ORDER BY net_gmv DESC;