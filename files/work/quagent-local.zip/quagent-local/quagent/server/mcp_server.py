#!/usr/bin/env python3
"""取数 Agent 的 MCP 服务器（stdio）。

只读工具：场景卡、表结构、列检索、指标口径、SQL 校验、限行执行。
复用 ../../workbench/sqlkit.py 的 guard / validate / explain / run。

用法（由 Harness 调起，也可手动跑）：
  python server/mcp_server.py
"""

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORKBENCH = ROOT.parent / "workbench"
sys.path.insert(0, str(WORKBENCH))

import sqlkit  # noqa: E402

from mcp.server.fastmcp import FastMCP  # noqa: E402

DB = Path(os.environ.get("QUJIAN_DB", ROOT / "scenario" / "anticheat.db"))
DOC = json.loads((ROOT / "scenario" / "schema_doc.json").read_text(encoding="utf-8"))
METRICS = (ROOT / "scenario" / "metrics.md").read_text(encoding="utf-8")
INSTRUCTIONS = (HERE / "instructions.md").read_text(encoding="utf-8")

mcp = FastMCP("qujian", instructions=INSTRUCTIONS, log_level="WARNING")


def _rows(query):
    out, code = sqlkit.run(DB, query, limit=1000, timeout=5)
    if code != 0:
        return []
    return out.get("rows", [])


_COUNTS = None


def _table_counts():
    global _COUNTS
    if _COUNTS is not None:
        return _COUNTS
    _COUNTS = {}
    for table in DOC["tables"]:
        rows = _rows('SELECT COUNT(*) AS n FROM "%s"' % table)
        _COUNTS[table] = rows[0][0] if rows else 0
    return _COUNTS


def _md_table(columns, rows, max_rows=100):
    def cell(value):
        if value is None:
            return "NULL"
        text = str(value).replace("|", "\\|").replace("\n", " ")
        return text

    lines = ["| " + " | ".join(columns) + " |",
             "| " + " | ".join("---" for _ in columns) + " |"]
    for row in rows[:max_rows]:
        lines.append("| " + " | ".join(cell(v) for v in row) + " |")
    if len(rows) > max_rows:
        lines.append("\n（仅展示前 %d 行，共 %d 行）" % (max_rows, len(rows)))
    return "\n".join(lines)


@mcp.tool()
def get_scenario() -> str:
    """返回当前取数场景：业务背景、时间范围、表清单、关联键与已知口径陷阱。"""
    s = DOC["scenario"]
    counts = _table_counts()
    lines = [
        "# " + s["title"],
        s["business"],
        "- 数据范围：%s 至 %s（UTC）" % (s["data_range"][0], s["data_range"][1]),
        "- 金额口径：%s" % s["currency"],
        "- 声明：%s" % s["disclaimer"],
        "",
        "## 表清单",
    ]
    for name, meta in DOC["tables"].items():
        lines.append("- `%s`（%s 行）：%s" % (name, counts.get(name, "?"), meta["grain"]))
    lines.append("")
    lines.append("## 关联键")
    for key in DOC["join_keys"]:
        lines.append("- " + key)
    lines.append("")
    lines.append("## 口径陷阱")
    for item in DOC["pitfalls"]:
        lines.append("- " + item)
    return "\n".join(lines)


@mcp.tool()
def get_schema(table: str = "") -> str:
    """查看表结构。table 留空时返回全部表；传入表名只返回该表。包含列类型、业务含义与行数。"""
    table = (table or "").strip()
    names = [table] if table else list(DOC["tables"].keys())
    unknown = [n for n in names if n not in DOC["tables"]]
    if unknown:
        return "未知表：%s。可用表：%s" % (", ".join(unknown), ", ".join(DOC["tables"]))
    counts = _table_counts()
    parts = []
    for name in names:
        meta = DOC["tables"][name]
        parts.append("## `%s`（%s 行）" % (name, counts.get(name, "?")))
        parts.append("粒度：%s" % meta["grain"])
        parts.append("| 列名 | 类型 | 业务含义 |")
        parts.append("| --- | --- | --- |")
        for col, info in meta["columns"].items():
            parts.append("| %s | %s | %s |" % (col, info["type"], info["desc"]))
        parts.append("")
    return "\n".join(parts).strip()


@mcp.tool()
def search_columns(keyword: str) -> str:
    """按关键词检索列名与业务含义，返回所属表、列名和说明。适合不确定字段在哪张表时使用。"""
    kw = (keyword or "").strip().lower()
    if not kw:
        return "请提供关键词，例如“退款”“设备”“时间”。"
    hits = []
    for table, meta in DOC["tables"].items():
        for col, info in meta["columns"].items():
            hay = ("%s %s %s" % (col, info["desc"], table)).lower()
            if kw in hay:
                hits.append("`%s.%s`（%s）：%s" % (table, col, info["type"], info["desc"]))
    if not hits:
        return "没有匹配“%s”的列。可先用 get_schema 查看全部表。" % keyword
    return "匹配“%s”的列：\n\n%s" % (keyword, "\n".join("- " + h for h in hits))


@mcp.tool()
def get_metrics() -> str:
    """返回指标口径：GMV、净 GMV、客单价、新客、复购、券核销、退款率与作弊嫌疑的定义。"""
    return METRICS


@mcp.tool()
def validate_sql(sql: str) -> str:
    """只编译不执行，检查 SQL 是否合法，并返回 SQLite 执行计划。写操作与多语句会被拒绝。"""
    out, code = sqlkit.validate(DB, sql)
    if code != 0:
        return "校验未通过：%s" % out.get("error", "未知错误")
    plan, _ = sqlkit.explain(DB, sql)
    lines = ["校验通过。", "", "执行计划："]
    for row in plan.get("plan", []):
        lines.append("- %s" % row.get("detail"))
    return "\n".join(lines)


@mcp.tool()
def run_sql(sql: str, limit: int = 100) -> str:
    """只读执行一条 SELECT/WITH/EXPLAIN，返回列名、行数、是否截断、耗时与结果表。默认最多 100 行，上限 200 行。"""
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 100
    limit = max(1, min(limit, 200))
    out, code = sqlkit.run(DB, sql, limit=limit, timeout=5)
    if code != 0:
        return "执行失败：%s\n\n请检查表名、列名与语法后重试。" % out.get("error", "未知错误")
    columns = out.get("columns", [])
    rows = out.get("rows", [])
    head = "行数：%d%s；耗时：%s ms" % (
        out.get("row_count", len(rows)),
        "（结果被截断，仅返回前 %d 行）" % limit if out.get("truncated") else "",
        out.get("elapsed_ms", "?"),
    )
    if not columns:
        return "查询已执行，但没有返回结果列。"
    return head + "\n\n" + _md_table(columns, rows, max_rows=limit)


def main():
    if not DB.exists():
        sys.stderr.write("数据库不存在：%s\n" % DB)
        raise SystemExit(2)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
