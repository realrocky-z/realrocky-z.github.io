#!/usr/bin/env python3
"""MCP 服务器自测：用官方 stdio 客户端连接，检查工具列表与六个工具的输出。

用法：
  python server/smoke_mcp.py
退出码 0 表示全部通过。
"""

import asyncio
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SERVER = HERE / "mcp_server.py"
DB = ROOT / "scenario" / "anticheat.db"

EXPECTED = {
    "get_scenario", "get_schema", "search_columns",
    "get_metrics", "validate_sql", "run_sql",
}


def text_of(result):
    return "\n".join(
        block.text for block in result.content if getattr(block, "type", "") == "text"
    )


async def main():
    env = dict(os.environ)
    env.update({
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
        "QUJIAN_DB": str(DB),
    })
    params = StdioServerParameters(
        command=sys.executable,
        args=[str(SERVER)],
        env=env,
        cwd=str(ROOT),
    )
    failures = []

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = await session.list_tools()
            names = {t.name for t in tools.tools}
            print("工具：", ", ".join(sorted(names)))
            missing = EXPECTED - names
            if missing:
                failures.append("缺少工具：%s" % ", ".join(sorted(missing)))

            scenario = text_of(await session.call_tool("get_scenario", {}))
            if "orders" not in scenario or "合成数据" not in scenario:
                failures.append("get_scenario 输出不完整")
            else:
                print("get_scenario ok")

            schema = text_of(await session.call_tool("get_schema", {"table": "orders"}))
            if "pay_amt" not in schema or "refund_amt" not in schema:
                failures.append("get_schema 输出不完整")
            else:
                print("get_schema ok")

            cols = text_of(await session.call_tool("search_columns", {"keyword": "退款"}))
            if "refund" not in cols:
                failures.append("search_columns 未命中退款列")
            else:
                print("search_columns ok")

            metrics = text_of(await session.call_tool("get_metrics", {}))
            if "净 GMV" not in metrics:
                failures.append("get_metrics 输出不完整")
            else:
                print("get_metrics ok")

            good = text_of(await session.call_tool(
                "validate_sql", {"sql": "SELECT COUNT(*) AS n FROM orders"}))
            if "校验通过" not in good:
                failures.append("validate_sql 拒绝了合法查询：%s" % good[:120])
            else:
                print("validate_sql ok")

            bad = text_of(await session.call_tool(
                "validate_sql", {"sql": "DROP TABLE orders"}))
            if "校验未通过" not in bad:
                failures.append("validate_sql 未拦截写操作：%s" % bad[:120])
            else:
                print("validate_sql 拦截写操作 ok")

            run = text_of(await session.call_tool(
                "run_sql", {"sql": "SELECT 1 AS n", "limit": 5}))
            if "| 1 |" not in run:
                failures.append("run_sql 结果异常：%s" % run[:160])
            else:
                print("run_sql ok")

            dirty = text_of(await session.call_tool(
                "run_sql", {"sql": "SELECT 1; DROP TABLE orders"}))
            if "执行失败" not in dirty:
                failures.append("run_sql 未拦截多语句：%s" % dirty[:120])
            else:
                print("run_sql 拦截多语句 ok")

    if failures:
        print("\nFAIL")
        for item in failures:
            print(" -", item)
        raise SystemExit(1)
    print("\nALL PASS")


if __name__ == "__main__":
    asyncio.run(main())
