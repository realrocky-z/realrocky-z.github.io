# 取数 Agent v1

把「理解业务问题 → 锁定口径 → 找表 → 写 SQL → 校验 → 限行执行 → 解释」做成可重复的取数流程。取数能力以 MCP 工具的形式挂进 DeepSeek Harness，界面就是 Harness 对话窗；模型由 Harness 现有登录态调用，不需要 API Key。

数据全部为合成数据，不含任何真实公司、用户或交易信息。

## 目录

```text
quagent/
  scenario/    合成库、表结构说明、指标口径、24 条评测题、作弊模式真值
  server/      MCP 服务器（6 个只读工具）与 stdio 自测
  eval/        答案评分脚本、答案目录、评测记录
  harness/     Harness 挂载配置与安装说明
```

## 快速开始

生成数据库（固定种子，可复现）：

```bash
cd "D:/弘(系统)/Documents/实实习习/业务能力1-大数据（SQL、Hive、Spark）/求职准备/quagent"
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/generate_data.py --db scenario/anticheat.db --seed 20261105 --force
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/build_questions.py --db scenario/anticheat.db
```

自测 MCP 服务器：

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python server/smoke_mcp.py
```

挂载 Harness：见 `harness/install.md`。

## 六个工具

| 工具 | 用途 |
|---|---|
| `get_scenario` | 业务背景、时间范围、表清单、关联键、口径陷阱 |
| `get_schema` | 表结构、列含义、行数；可按表查询 |
| `search_columns` | 按关键词找列 |
| `get_metrics` | GMV、净 GMV、新客、复购、券核销、退款、作弊嫌疑口径 |
| `validate_sql` | 只编译不执行，返回执行计划；拒绝写操作与多语句 |
| `run_sql` | 只读执行，默认 100 行、上限 200 行、5 秒超时 |

安全边界复用 `../workbench/sqlkit.py`：`PRAGMA query_only=ON`，只允许单条 `SELECT`/`WITH`/`EXPLAIN`，拒绝 `INSERT/UPDATE/DELETE/DROP/...`，每次查询写入 `scenario/query-log.jsonl`。

## 数据场景

七张表：`users`、`devices`、`riders`、`merchants`、`orders`、`events`、`coupons`。约 5000 用户、60430 订单、20150 张券、120000 条行为日志，覆盖六个海外城市，时间范围 2026-10-05 至 2026-11-01。

埋入五类可验证模式（真值在 `scenario/labels.csv`，仅评测用）：

| 模式 | 规模 |
|---|---|
| 设备农场 | 30 个新账号共用 2 台设备，处置前 300 单，处置后 0 单 |
| 券滥用 | 150 人领券 60 秒内核销并退款 |
| 骑手自交易 | 20 对骑手与账号共用设备，100 单 |
| 退款环 | 4 家商家，每家 60 单中 24 单退款，约 40% |
| 频次异常 | 80 人一小时内下单 8 单 |

正常流量占多数，规则会命中部分非埋入账号，适合讨论精确率与规则迭代。

## 评测

1. 在 Harness 里按 `scenario/questions.csv` 逐题提问，要求把最终 SQL 写入 `eval/answers/Qxx.sql`。
2. 运行评分：

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python eval/check_answers.py --answers eval/answers --golden scenario/questions.csv --write
```

评分规则：忽略列别名，比列数与结果集；golden 带 `LIMIT` 时按顺序比，否则按集合比；数值容差 0.01。结果写入 `eval/scoreboard.md`。

24 题覆盖规模、新客、优惠券、设备、骑手、商家、作弊特征与策略评估，难度分布 easy 6 / medium 12 / hard 6。

## 与目标岗位的对应

| JD 要求 | 本项目对应 |
|---|---|
| 理解业务模式与潜在风险 | 场景卡、五类作弊模式、`metrics.md` 口径 |
| SQL/Hive/Spark 取数 | 24 条业务题与 golden SQL |
| 识别作弊行为特征 | 多账号设备、券滥用、频次异常、自交易规则 |
| 策略验证与效果评估 | Q24 处置前后对比 |
| 监控指标体系 | `metrics.md` 与每日/城市维度题 |
| 掌握 AI 能力 | MCP 工具、结果判定评测、可复现流程 |

## 边界

- SQLite 方言，不是 Hive/Spark；日期函数与 `LIMIT` 语义有差异，迁移时需改写。
- 合成数据只能证明方法与流程，不代表真实业务结论。
- 规则命中不等于确认作弊；评测衡量的是取数正确性，不是作弊判定准确率。
- 当前没有自动跑模型的评测；答案由人在 Harness 中逐题产生，评分是确定性的。
