#!/usr/bin/env python3
"""只读 SQLite 工作台，供 agent 取数与自检。

命令：
  python sqlkit.py init     --db workbench.db [--seed seed.sql] [--force]
  python sqlkit.py schema   --db workbench.db
  python sqlkit.py validate --db workbench.db --sql "SELECT ..."
  python sqlkit.py explain  --db workbench.db --sql "SELECT ..."
  python sqlkit.py run      --db workbench.db --sql "SELECT ..." [--limit 50]
  python sqlkit.py eval     --db workbench.db --golden golden.csv

输出 JSON；退出码 0 成功，1 查询被拒/失败，2 参数或 IO 错误。
"""

import argparse
import csv
import json
import re
import sqlite3
import sys
import time
from pathlib import Path

DEFAULT_LIMIT = 200
MAX_LIMIT = 1000
DEFAULT_TIMEOUT = 5.0
FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|REPLACE|TRUNCATE|GRANT|REVOKE)\b",
    re.I,
)
ALLOWED_FIRST = re.compile(r"^\s*(SELECT|WITH|EXPLAIN)\b", re.I)


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
    return code


def strip_comments(sql):
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", " ", sql)
    sql = re.sub(r"#[^\n]*", " ", sql)
    return sql


def split_statements(sql):
    parts, buf, quote = [], [], None
    for ch in sql:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in ("'", '"'):
            quote = ch
            buf.append(ch)
            continue
        if ch == ";":
            parts.append("".join(buf))
            buf = []
            continue
        buf.append(ch)
    parts.append("".join(buf))
    return [p.strip() for p in parts if p.strip()]


def guard(sql):
    """返回 (ok, 规范化 SQL, 错误原因)。"""
    clean = strip_comments(sql)
    parts = split_statements(clean)
    if len(parts) != 1:
        return False, clean, "只允许单条语句，实际有 %d 条" % len(parts)
    one = parts[0]
    if not ALLOWED_FIRST.search(one):
        return False, one, "只允许 SELECT / WITH / EXPLAIN"
    bad = FORBIDDEN.search(one)
    if bad:
        return False, one, "拒绝写操作或危险关键字：%s" % bad.group(1).upper()
    return True, one, ""


def connect_ro(db):
    db = Path(db)
    if not db.exists():
        raise FileNotFoundError("数据库不存在：%s" % db)
    conn = sqlite3.connect(str(db))
    conn.execute("PRAGMA query_only = ON")
    return conn


def log_call(db, payload):
    try:
        path = Path(db).parent / "query-log.jsonl"
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except OSError:
        pass


def with_timeout(conn, seconds):
    deadline = time.monotonic() + seconds

    def handler():
        return 1 if time.monotonic() > deadline else 0

    conn.set_progress_handler(handler, 1000)


def schema(db):
    conn = connect_ro(db)
    try:
        names = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )]
        tables = {}
        for name in names:
            ident = '"' + name.replace('"', '""') + '"'
            cols = []
            for row in conn.execute("PRAGMA table_info(%s)" % ident):
                cols.append({"name": row[1], "type": row[2], "notnull": bool(row[3]), "pk": bool(row[5])})
            tables[name] = cols
        return {"ok": True, "db": str(db), "tables": tables}
    finally:
        conn.close()


def explain(db, sql):
    ok, one, err = guard(sql)
    if not ok:
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "explain", "sql": sql, "allowed": False, "reason": err})
        return {"ok": False, "error": err}, 1
    conn = connect_ro(db)
    try:
        rows = conn.execute("EXPLAIN QUERY PLAN " + one).fetchall()
        plan = [{"id": r[0], "parent": r[1], "notused": r[2], "detail": r[3]} for r in rows]
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "explain", "sql": one, "allowed": True, "rows": len(plan)})
        return {"ok": True, "plan": plan}, 0
    except sqlite3.Error as exc:
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "explain", "sql": one, "allowed": True, "error": str(exc)})
        return {"ok": False, "error": str(exc)}, 1
    finally:
        conn.close()


def validate(db, sql):
    ok, one, err = guard(sql)
    if not ok:
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "validate", "sql": sql, "allowed": False, "reason": err})
        return {"ok": False, "error": err}, 1
    conn = connect_ro(db)
    try:
        conn.execute("EXPLAIN " + one).fetchall()
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "validate", "sql": one, "allowed": True})
        return {"ok": True, "sql": one}, 0
    except sqlite3.Error as exc:
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "validate", "sql": one, "allowed": True, "error": str(exc)})
        return {"ok": False, "error": str(exc)}, 1
    finally:
        conn.close()


def run(db, sql, limit=DEFAULT_LIMIT, timeout=DEFAULT_TIMEOUT):
    limit = max(1, min(int(limit), MAX_LIMIT))
    ok, one, err = guard(sql)
    if not ok:
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "run", "sql": sql, "allowed": False, "reason": err})
        return {"ok": False, "error": err}, 1
    start = time.monotonic()
    conn = connect_ro(db)
    try:
        with_timeout(conn, timeout)
        cur = conn.execute(one)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchmany(limit + 1)
        truncated = len(rows) > limit
        rows = rows[:limit]
        clean_rows = [[v if not isinstance(v, bytes) else v.hex() for v in row] for row in rows]
        elapsed = round((time.monotonic() - start) * 1000, 2)
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "run", "sql": one,
                      "allowed": True, "rows": len(rows), "truncated": truncated, "elapsed_ms": elapsed})
        return {"ok": True, "columns": cols, "rows": clean_rows, "row_count": len(rows),
                "truncated": truncated, "elapsed_ms": elapsed}, 0
    except sqlite3.Error as exc:
        elapsed = round((time.monotonic() - start) * 1000, 2)
        log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "run", "sql": one,
                      "allowed": True, "error": str(exc), "elapsed_ms": elapsed})
        return {"ok": False, "error": str(exc)}, 1
    finally:
        conn.close()


def init_db(db, seed, force=False):
    db = Path(db)
    if db.exists() and not force:
        return {"ok": False, "error": "数据库已存在；加 --force 覆盖：%s" % db}, 1
    seed = Path(seed)
    if not seed.exists():
        return {"ok": False, "error": "种子文件不存在：%s" % seed}, 2
    if db.exists():
        db.unlink()
    conn = sqlite3.connect(str(db))
    try:
        conn.executescript(seed.read_text(encoding="utf-8"))
        conn.commit()
        count = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
        return {"ok": True, "db": str(db), "tables": count}, 0
    except sqlite3.Error as exc:
        return {"ok": False, "error": str(exc)}, 1
    finally:
        conn.close()


def evaluate(db, golden):
    golden = Path(golden)
    if not golden.exists():
        return {"ok": False, "error": "评测文件不存在：%s" % golden}, 2
    rows = list(csv.DictReader(golden.open(encoding="utf-8-sig", newline="")))
    results = []
    passed = 0
    for r in rows:
        sql = (r.get("golden_sql") or "").strip()
        expect = [c.strip() for c in (r.get("expect_columns") or "").split("|") if c.strip()]
        ok, one, err = guard(sql)
        if not ok:
            results.append({"id": r.get("id"), "ok": False, "error": err})
            continue
        out, code = run(db, one, limit=MAX_LIMIT)
        if code != 0:
            results.append({"id": r.get("id"), "ok": False, "error": out.get("error")})
            continue
        cols = out.get("columns") or []
        match = [c.lower() for c in cols] == [c.lower() for c in expect] if expect else True
        results.append({"id": r.get("id"), "ok": match, "columns": cols,
                        "expect": expect, "rows": out.get("row_count"), "elapsed_ms": out.get("elapsed_ms")})
        if match:
            passed += 1
    summary = {"ok": passed == len(results), "passed": passed, "total": len(results), "results": results}
    log_call(db, {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "cmd": "eval", "passed": passed, "total": len(results)})
    return summary, 0 if passed == len(results) else 1


def main():
    ap = argparse.ArgumentParser(description="只读 SQLite 工作台")
    ap.add_argument("command", choices=["init", "schema", "validate", "explain", "run", "eval"])
    ap.add_argument("--db", default="workbench.db")
    ap.add_argument("--seed", default=str(Path(__file__).with_name("seed.sql")))
    ap.add_argument("--golden", default=str(Path(__file__).with_name("golden.csv")))
    ap.add_argument("--sql")
    ap.add_argument("--limit", type=int, default=DEFAULT_LIMIT)
    ap.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    try:
        if args.command == "init":
            obj, code = init_db(args.db, args.seed, args.force)
        elif args.command == "schema":
            obj, code = schema(args.db), 0
        elif args.command == "eval":
            obj, code = evaluate(args.db, args.golden)
        else:
            if not args.sql:
                obj, code = {"ok": False, "error": "缺少 --sql"}, 2
            elif args.command == "validate":
                obj, code = validate(args.db, args.sql)
            elif args.command == "explain":
                obj, code = explain(args.db, args.sql)
            else:
                obj, code = run(args.db, args.sql, args.limit, args.timeout)
    except FileNotFoundError as exc:
        obj, code = {"ok": False, "error": str(exc)}, 2
    except Exception as exc:
        obj, code = {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}, 2

    sys.exit(emit(obj, code))


if __name__ == "__main__":
    main()
