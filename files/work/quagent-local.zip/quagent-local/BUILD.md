# quagent 从业务问题到可评测的只读取数 Agent 的搭建记录

这条链路的结论是，模型不直接连数据库，只能调用六个边界明确的只读工具；查询在进入数据库前过 guard，执行时限额、限时、留日志；答案对不对由 golden SQL（标准答案 SQL）的结果集判定，而不是看模型写得像不像。下面按实际搭建顺序拆成八步，每一步给出关键文件、核心代码、设计理由和验证命令。

当前可核验的 baseline 是，`server/smoke_mcp.py` 输出 `ALL PASS`；24 条 golden SQL 全部可在模拟数据库上执行且列名符合 `expect_columns`；人工在 Harness 中作答并评分的部分只有 Q01 通过（`eval/scoreboard.md` 记录 1/24）。不把 24 条 golden SQL 可执行等同于 24 题已通过。

## 0. 先定验收标准

在写代码前先写清楚什么算完成。

- 取数流程可重复，同一个业务问题，按「锁口径 → 找表 → 写 SQL → 校验 → 限行执行 → 解释」走，不依赖临场发挥。
- 安全边界在代码里，即使模型输出 `DROP TABLE`，也执行不了。
- 正确性可判定，24 道题的参考答案以 SQL 形式固定，比对列数与结果集，数值允许 0.01 的误差。
- 数据可公开，全部为合成数据，固定随机种子，不含真实公司、用户或交易信息。

这四条对应后面的八步。没有第 4 条的判定标准，第 8 步的展示就只能靠口头承诺。

## 1. 把场景和口径写成文件

**文件**是 `scenario/schema_doc.json` 和 `scenario/metrics.md`。

具体做法是，先用 JSON 写清业务背景、时间范围、七张表每一行代表什么、关联键和已知口径陷阱；再用 Markdown 固定指标定义。关键口径直接写死。

- 净 GMV = `SUM(pay_amt - refund_amt)`，默认只算 `status = 'delivered'`。
- 用户规模按 `user_id` 去重，不能按设备或订单行数算。
- 券未核销用 `used_ts IS NULL` 判断。
- 规则命中不等于确认作弊。

这样做的理由是，Agent 最常见的错误不是 SQL 语法，而是口径漂移。把口径放在工具里、要求模型先读再写，比在提示词里反复叮嘱可靠。`schema_doc.json` 同时是 `get_scenario`、`get_schema`、`search_columns` 三个工具的唯一数据源，改一处即可全局生效。

检查办法是，`scenario/schema_doc.json` 能被 `json.load` 解析；每张表的 `columns` 覆盖实际建表语句中的列。

## 2. 生成可复现的合成数据

**文件**是 `scenario/generate_data.py`。

具体做法是，用固定种子生成七张表，并埋入五类可验证模式。

```bash
cd "D:/弘(系统)/Documents/实实习习/业务能力1-大数据（SQL、Hive、Spark）/求职准备/quagent"
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/generate_data.py \
  --db scenario/anticheat.db --seed 20261105 --force
```

规模是 5,000 用户、60,430 订单、20,150 张券、120,000 条行为日志；另含设备、骑手、商家表。时间范围 2026-10-05 至 2026-11-01。

五类模式与真值文件 `scenario/labels.csv` 如下。

| 模式 | 规模 |
|---|---|
| 设备农场 | 30 个新账号共用 D900001/D900002，处置前 300 单，处置后 0 单 |
| 券滥用 | 150 人领券后 60 秒内核销并退款 |
| 骑手自交易 | 20 对骑手与账号共用设备，100 单 |
| 退款环 | 4 家商家，每家 60 单中 24 单退款，约 40% |
| 频次异常 | 80 人一小时内下单 8 单 |

这样做的理由是，真实业务数据不能进外部模型，合成数据可以把「方法可复现」和「隐私可控」同时满足。埋入模式是为了让评测题有确定答案，而不是等真实作弊样本。

检查办法是，重跑同一 seed，`scenario/anticheat.db` 的行数与真值标签一致；`labels.csv` 只用于评测，不暴露给模型工具。

## 3. 出题并固定标准答案 SQL

**文件**是 `scenario/build_questions.py`、`scenario/questions.csv`

具体做法是，把 24 道题写进 Python 列表，每题包含题干、`expect_columns`、`golden_sql`、类别、难度、技能标签。脚本逐条执行 golden SQL，列名必须与 `expect_columns` 一致，全部通过才写出 CSV。

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/build_questions.py --db scenario/anticheat.db
```

难度分布按代码实际统计为 easy 6、medium 12、hard 6。题目覆盖规模、新客、优惠券、设备、骑手、商家、作弊特征与策略评估八类。

这样做的理由是，先有可执行的参考答案，才有资格谈「评测」。`expect_columns` 是接口契约，列顺序固定；评分器按位置比对，不按列名匹配。这个选择有代价，`eval/errors.md` 记录了 Q01 因列顺序不符被判不一致的案例，保留该规则的理由是对外结果表本来就应有稳定列序。

检查办法是，脚本输出 24 行 `Qxx ok`；`questions.csv` 为 24 行，`golden_sql` 列非空。

## 4. 写安全内核

**文件**是 `workbench/sqlkit.py`（与 `quagent` 同级，被多处复用）

具体做法是，所有查询执行都经过同一个 `guard` 函数。

```python
FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|ATTACH|DETACH|PRAGMA|VACUUM|"
    r"REINDEX|REPLACE|TRUNCATE|GRANT|REVOKE)\b", re.I)
ALLOWED_FIRST = re.compile(r"^\s*(SELECT|WITH|EXPLAIN)\b", re.I)
```

`guard` 的顺序是，剥注释 → 在引号外切分号 → 必须恰好一条语句 → 首关键字必须是 `SELECT`/`WITH`/`EXPLAIN` → 扫禁用词。执行侧再做四件事。

- `connect_ro` 每次连接执行 `PRAGMA query_only = ON`。
- `run` 只取 `limit + 1` 行，多出来的一行只用于判断截断，实际返回 `limit` 行；上限 1000。
- `with_timeout` 用 `set_progress_handler` 做 5 秒超时。
- `log_call` 把时间、SQL、是否放行、原因、行数、耗时写入 `scenario/query-log.jsonl`。

这样做的理由是，提示词可以写「不要执行写操作」，但模型可能不遵守；代码里的四层约束不依赖模型配合。`query_only` 是数据库级兜底，白名单和多语句拒绝是 SQL 级前置检查，限额和超时控制影响面，日志让事后审计有据可查。

已知缺陷是，Python 版 `strip_comments` 是正则，会误删字符串里的 `--` 或 `/* */`。浏览器移植版改成了单遍词法扫描，只处理引号外的注释，并补了对反引号、方括号和未闭合引号的处理。

检查办法是，`python server/smoke_mcp.py` 覆盖合法查询、`DROP TABLE` 拦截和多语句拦截；Node 侧 20 条 guard/compare 单测覆盖引号内分号、字符串内关键字、未闭合引号与 NUL。

## 5. 把能力包成六个只读工具

**文件**是 `server/mcp_server.py`、`server/instructions.md`

具体做法是，用 FastMCP 起一个 stdio 服务器，暴露六个工具。

| 工具 | 作用 | 边界 |
|---|---|---|
| `get_scenario` | 业务背景、时间范围、表清单、关联键、口径陷阱 | 只读配置 |
| `get_schema` | 表结构、列类型、含义、行数 | 可按表过滤 |
| `search_columns` | 按关键词检索列 | 只搜文档 |
| `get_metrics` | 指标口径原文 | 只读 Markdown |
| `validate_sql` | 编译不执行，返回执行计划 | 走 guard |
| `run_sql` | 限行执行 | 默认 100 行、上限 200 行、5 秒 |

`instructions.md` 规定的工作流是，复述并锁定口径 → 调 `get_scenario` → 先计划再写 SQL → 先 `validate_sql` 再 `run_sql` → 最多修正三次 → 按固定结构输出结论、口径、SQL、结果、局限。

这样做的理由是，工具边界清晰，才能单独测试、替换和审计。模型看到的是「查文档」和「执行只读查询」两类能力，没有任意代码执行入口。`run_sql` 的参数限幅在服务器端再做一次，不信任模型传入的 `limit`。

检查办法是，`smoke_mcp.py` 用官方 stdio 客户端连接，检查六个工具都存在，并断言写操作、多语句被拒，合法查询能返回结果。

## 6. 挂载到 Harness

**文件**是 `harness/cordis.snippet.yml`、`harness/install.md`

具体做法是，在 `~/.dsh/profiles/desktop/cordis.patch.yml` 末尾追加一个 MCP client 项，命令指向本机 Python，`cwd` 与 `QUJIAN_DB` 指向项目路径，传输方式为 stdio。改配置前先备份，重启 Harness 后在对话里调用 `mcp__qujian__*`。

这样做的理由是，Agent 不自己维护登录态和模型调用，只提供工具；模型由 Harness 现有登录态调用，不需要额外 API Key。stdio + 本机路径把数据边界限制在本地。

检查办法是，在 Harness 里问「你现在有哪些取数工具」，应能看到六个工具；失败时按 `install.md` 的顺序查连接错误、模块缺失、路径引号和数据库路径。

## 7. 建评测闭环

**文件**是 `eval/check_answers.py`、`eval/answers/`、`eval/scoreboard.md`、`eval/errors.md`

具体做法是，人工在 Harness 里逐题提问，把模型最终 SQL 存成 `eval/answers/Qxx.sql`，再跑评分。

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python eval/check_answers.py \
  --answers eval/answers --golden scenario/questions.csv --write
```

判分规则与 `sqlkit.run` 一致，先比列数；再分别执行 golden SQL 和提交的答案，数值允许 0.01 的误差，NULL 只匹配 NULL，字符串 trim；golden SQL 含 `LIMIT` 时按顺序比，否则按多重集比。结果写入 `scoreboard.md`。

这样做的理由是，模型输出的 SQL 可能写法不同但结果正确，所以比结果集不比字符串。含 `LIMIT` 的题顺序有业务含义（例如「退款率最高的 10 家」），必须按顺序比。

检查办法是，当前 `scoreboard.md` 显示已作答 1/24、通过 1/24；`errors.md` 记录了 Q01 列顺序错误的现象、原因、类别与改法。

## 8. 做可交互的展示层

**文件**是 `个人主页/work/quagent/`、`个人主页/scripts/build_quagent_demo.py`

具体做法是，把同一套 guard 与判分规则移植到浏览器，用 sql.js 在 Web Worker 里真实执行 SQL。页面提供 24 题选题、SQL 编辑器、校验、执行、自动判分、安全拦截示例和本地审计日志。

数据不直接搬 34MB 原库，构建脚本删除 `events` 表与全部显式索引后 VACUUM，再以 `mtime=0`、level 9 压缩。结果是 6 张表、11.3MB 原始、约 3.5MB gzip；24 题均不依赖 `events`，裁剪后最慢一条 golden SQL 约 172ms。

这样做的理由是，一页 PDF 只能证明「做过」，交互页能让访问者自己写一条 `DROP TABLE` 看它在 guard 层被拒，或写一条查询看结果与 golden SQL 是否一致。浏览器内执行也意味着查询不离开本机；`PRAGMA query_only=ON` 仍然保留，保持与源项目行为一致。

检查办法是，`node --test tests/*.test.mjs` 20 条通过；本地 HTTP 服务下加载示例数据、Q01 作答通过、四类写操作被拒、`SELECT *` 只显示前 200 行、笛卡尔积 5 秒终止。

## 复现顺序

```bash
cd "D:/弘(系统)/Documents/实实习习/业务能力1-大数据（SQL、Hive、Spark）/求职准备/quagent"

# 1-2 生成数据（--force 会覆盖现有库，先确认没有要保留的改动）
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/generate_data.py \
  --db scenario/anticheat.db --seed 20261105 --force

# 3 生成并验证题库
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python scenario/build_questions.py --db scenario/anticheat.db

# 5 工具层自测
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python server/smoke_mcp.py

# 7 评分（先在 eval/answers/ 放入答案）
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python eval/check_answers.py \
  --answers eval/answers --golden scenario/questions.csv --write
```

## 边界与未完成

- SQLite 方言，不是 Hive/Spark；日期函数、分区过滤和 `LIMIT` 语义迁移时都要改写。
- 合成数据只能证明方法与流程，不代表真实业务结论。规则命中不等于确认作弊。
- Agent 评测目前只有 Q01 人工作答通过；24 条 golden SQL 全部可执行，不等于 24 题已通过。
- 没有 CI、依赖许可证扫描和自动化的模型评测；这些是下一步，不在当前基线内。
