# 只读取数助手 · 本地完整项目

这个包里的 `quagent/` 是真正的取数助手。模型通过 MCP 调用六个只读工具，可以回答任意业务问题；`questions.csv` 里的 24 道题只是评测集。

## 目录

- `quagent/server/` 是 MCP 服务器，暴露 `get_scenario`、`get_schema`、`search_columns`、`get_metrics`、`validate_sql`、`run_sql` 六个工具。
- `quagent/scenario/` 是场景说明、指标定义、题库，以及一份 6 张表的示例库 `anticheat.db`。
- `workbench/sqlkit.py` 是查询护栏，必须和 `quagent/` 保持同级，服务器启动时会按相对路径找到它。
- `quagent/harness/` 是挂载到 Harness 的配置片段和步骤。
- `quagent/eval/` 是评分脚本与当前进度。

## 运行

需要 Python 3.11 或更高版本。

1. 安装依赖。

   ```bash
   python -m pip install "mcp[cli]"
   ```

2. 自测工具层。

   ```bash
   python quagent/server/smoke_mcp.py
   ```

   看到 `ALL PASS` 说明只读工具、写操作拦截和多语句拦截都正常。

3. 挂载到 Harness。打开 `quagent/harness/install.md`，把 `cordis.snippet.yml` 里的路径改成你解压后的实际路径，追加到配置里，重启 Harness。

4. 在 Harness 里直接问业务问题，例如「上周各城市净 GMV 是多少」。模型会先读场景和指标，再写 SQL，先校验再执行。

## 关于示例库

示例库删掉了 `events` 表，把体积压到约 3.5MB，24 道题都不依赖它。需要完整的行为日志时，在 `quagent/` 目录运行：

```bash
python scenario/generate_data.py --db scenario/anticheat.db --seed 20261105 --force
```

随机种子固定，重建后数据与原项目一致。`--force` 会覆盖当前的示例库。

## 边界

数据全部为合成数据。规则命中不等于确认作弊。SQLite 方言不是 Hive/Spark，日期函数和分区写法迁移时要改写。
