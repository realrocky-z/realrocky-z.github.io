# SQL 练习台与只读取数工具

这是一个使用合成数据的本地 MCP 项目，不包含模型或 API 凭据。在线练习台与本地工具是两个使用入口。

## 运行

需要 Python 3.11 或更新版本。在解压后的项目根目录运行：

```bash
python -m pip install "mcp[cli]"
python quagent/server/smoke_mcp.py
```

自测通过说明工具层的列举、查询和示例拒绝测试通过，不代表所有查询正确。

在支持 MCP 的客户端里配置 stdio 服务：命令为 `python`，参数为你自己电脑上 `quagent/server/mcp_server.py` 的路径。不要将完成配置后的私人路径或凭据提交到公开仓库。

## 包含什么

- `quagent/server/`：查看场景、表结构、搜索字段、指标定义、检查 SQL 和执行查询的六项工具。
- `quagent/scenario/`：六张表的合成 SQLite 数据库、指标文档、24 道题及数据生成脚本。示例库不含 events 表。
- `workbench/sqlkit.py`：语句检查、只读连接、返回行数与超时控制。
- `quagent/eval/`：结果比对脚本和历史提交记录。历史记录只包含 Q01，不应解释为模型已经答对全部题目。

本地 run_sql 默认返回 100 行，最多 200 行，超时设置为 5 秒。使用前请核对指标口径；可执行的 SQL 也可能答错问题。

## 数据与验证

所有数据均为合成数据，不含真实业务记录。SQLite 不等同于 Hive 或 Spark，规则命中不等于确认作弊。

Q20 按 gmv 字段统计商品原价；Q21 按 user_id 去重统计命中用户，不能统计用户与小时组合数。当前数据上，命中用户为 159，命中小时内订单为 1643。

24 题在当前数据上的结果值已用独立 Python 聚合复算。该检查不覆盖所有边界数据、并列排序或模型作答能力。历史提交记录保留原样，不把参考查询冒充用户提交。

## 重新生成数据

在 `quagent/` 目录运行下面的命令会覆盖数据库，仅在保留备份后使用：

```bash
python scenario/generate_data.py --db scenario/anticheat.db --seed 20261105 --force
python scenario/build_questions.py --db scenario/anticheat.db
```

## 使用示例

先查看场景和指标定义，再检查并执行：

```sql
SELECT city, COUNT(*) AS orders,
       ROUND(SUM(pay_amt - refund_amt), 2) AS net_gmv
FROM orders
WHERE order_ts >= '2026-10-26' AND order_ts < '2026-11-02'
  AND status = 'delivered'
GROUP BY city
ORDER BY net_gmv DESC;
```

这里按订单表 city 分组；若题目指定用户所在城市，应关联 users 表。比对是比较结果表，不是比较 SQL 文本，也不是对业务结论的保证。
