# quagent 面试演示脚本（2 分钟）

## 一句话定位

把「业务问题 → 锁定口径 → 找表 → 写 SQL → 校验 → 限行执行 → 解释结果」做成可重复的只读取数流程，工具以 MCP 形式挂进 Claude Code。

## 演示前检查

```bash
cd "D:/弘(系统)/Documents/实实习习/业务能力1-大数据（SQL、Hive、Spark）/求职准备/quagent"
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 python server/smoke_mcp.py
```

`ALL PASS` 后再演示。MCP 配置在上一级 `.mcp.json`，需从 `求职准备/` 目录启动 Claude Code 并在信任提示中允许。

## 演示步骤

### 1. 场景与口径（get_scenario）

> 「先让 Agent 读场景卡，确认数据范围、表清单和口径陷阱，而不是直接写 SQL。」

### 2. 看表结构（get_schema）

参数：`{"table": "orders"}`。重点指出 `pay_amt = gmv - discount_amt`、`refund_amt` 仅退款单非零。

### 3. 指标口径（get_metrics）

> 「净 GMV 不是简单 SUM(gmv)，要扣优惠和退款；口径先对齐，再取数。」

### 4. 校验再执行（validate_sql → run_sql）

```sql
SELECT city,
       COUNT(*) AS orders,
       ROUND(SUM(pay_amt), 2) AS net_gmv,
       ROUND(1.0 * SUM(refund_amt) / NULLIF(SUM(pay_amt), 0), 3) AS refund_rate
FROM orders
GROUP BY city
ORDER BY net_gmv DESC;
```

先 `validate_sql` 看执行计划，再 `run_sql`（默认 100 行、上限 200 行、5 秒超时）。

### 5. 追一个业务问题：券滥用

```sql
SELECT campaign,
       COUNT(*) AS coupons,
       SUM(CASE WHEN used_ts IS NOT NULL THEN 1 ELSE 0 END) AS used,
       ROUND(1.0 * SUM(CASE WHEN used_ts IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 3) AS use_rate
FROM coupons
GROUP BY campaign
ORDER BY use_rate DESC;
```

> 「如果某个活动核销率异常高、且退款集中，就要回到订单表核对领券到核销的时间差和退款率。」

## 安全边界（主动说）

- 只读：`PRAGMA query_only=ON`，只允许单条 `SELECT`/`WITH`/`EXPLAIN`，拒绝 `INSERT/UPDATE/DELETE/DROP` 与多语句。
- 限行 200、超时 5 秒，每次查询写 `scenario/query-log.jsonl`。
- 合成数据，不含真实公司或用户信息。

## 必须说明的局限

- SQLite 方言，不是 Hive/Spark；日期函数与 `LIMIT` 语义有差异，迁移时要改写。
- 规则命中不等于确认作弊；评测衡量取数正确性，不是作弊判定准确率。
- 24 条评测题由人在 Harness 中逐题产生答案，评分是确定性的。

## 可能被追问

1. 为什么不直接让模型生成 SQL 跑库？——口径需要人审批，Agent 只做校验、限行执行和解释。
2. 怎么防止写操作？——`query_only` + 语句白名单 + 多语句拒绝，三层。
3. 换成 Hive 要改什么？——日期函数、分区过滤、`LIMIT` 语义、执行计划；工作流不变。
4. 评测怎么做的？——24 题 golden SQL，列数/结果集/容差 0.01，分数写入 `eval/scoreboard.md`。
